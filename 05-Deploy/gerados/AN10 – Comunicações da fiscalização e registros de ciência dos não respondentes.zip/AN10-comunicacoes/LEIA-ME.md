# AN10 — Comunicações das organizações não respondentes

Coleção de mensagens da Fiscalização TCE-RJ nº 18/2026 (iGovTI 2026), extraídas em modo somente leitura da caixa `auditoriati@tcerj.tc.br`.

## Estrutura e método

Cada e-mail corresponde a um arquivo HTML. Quando o item original informa anexos, estes ficam na pasta de mesmo nome acrescida de `_anexos`. Os mapeamentos de organização, TSID e tipo constam apenas no nome do arquivo e nos índices.

Foram varridas, de janeiro de 2026 até a data da extração, as pastas `Caixa de entrada`, `2026_Audit_iGovTI` e `Mensagens enviadas`. A listagem inicial consultou somente metadados; corpos e anexos foram obtidos apenas para candidatos. Itens repetidos foram deduplicados pelo cabeçalho Message-ID e, quando ausente, por MD5 de assunto, data e autor. As mensagens da Fiscalização de Contratações SETIC do exercício anterior foram excluídas.

Os horários dos nomes de arquivo e do campo `data_brasil` estão em America/Sao_Paulo (UTC-03 no período). O índice também registra a data UTC. Os documentos HTML não contêm UTC nem texto de contextualização: somente os campos e o corpo do próprio e-mail.

## Quantitativo

| Organização | TSID01 | TSID02 | TSID03 | Total |
|---|---:|---:|---:|---:|
| CEHAB | 3 | 3 | 2 | 8 |
| EMOP | 2 | 6 | 2 | 10 |
| PESAGRO | 2 | 5 | 1 | 8 |
| SEDCON | 4 | 3 | 1 | 8 |
| SEPOL | 2 | 6 | 2 | 10 |
| SESP | 4 | 4 | 7 | 15 |

Total: **59 e-mails**.

## Limitações conhecidas

O envio original do TSID01 de CEHAB, EMOP, PESAGRO e SEPOL não foi localizado nas três pastas consultadas; sua recuperação depende das caixas pessoais da equipe ou do SEI.

A referência preliminar indicava 49 mensagens. A varredura encontrou ainda dez itens que atendem aos critérios definidos: seis respostas recebidas no TSID01 (duas da CEHAB, uma da EMOP, uma da SEDCON e duas da SESP) e quatro confirmações iniciais de leitura do TSID02 (CEHAB, EMOP, SEPOL e SESP). Eles foram mantidos para preservar a completude da coleção.

Não houve mensagem classificada pela regra residual de TSID01.

## Diagnóstico da varredura

- Caixa de entrada: 317 itens no período; 15 candidatos; busca no corpo=ok; exclusões explícitas da fiscalização SETIC anterior=0.
- Mensagens enviadas: 667 itens no período; 33 candidatos; busca no corpo=ok; exclusões explícitas da fiscalização SETIC anterior=0.
- 2026_Audit_iGovTI: 238 itens no período; 13 candidatos; busca no corpo=ok; exclusões explícitas da fiscalização SETIC anterior=0.
